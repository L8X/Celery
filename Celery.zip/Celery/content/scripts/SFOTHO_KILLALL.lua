user = game.Players.LocalPlayer;
if user.Backpack:FindFirstChild("Sword") then
    user.Character.Humanoid:EquipTool(user.Backpack.Sword);
end
wait(1);
user.Character.Sword.Handle.Size=Vector3.new(4e4,4e4,4e4)

-- now click alot of times!