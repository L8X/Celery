local insertService = game:GetService("InsertService");

local gameMt = getrawmetatable(game);
local gameRealIndex = gameMt.__index;
local gameRealNameCall = gameMt.__namecall;

setreadonly(gameMt, false);

gameMt.__index = function(a,name,...)
  if name == "HttpGet" then
    return function(_, url, async) 
      return httpget(url, async)
    end
  elseif name == "GetObjects" then
    return function(_, k)
      return { insertService:LoadLocalAsset(k) }
    end
  end
  return gameRealIndex(a,name,...);
end

gameMt.__namecall = function(a,...)
  if checkcaller() then
    local name = getnamecallmethod();
    if name == "HttpGet" then
      return httpget(...);
    elseif name == "GetObjects" then
      return function(k)
        return { insertService:LoadLocalAsset(k) }
      end
    end
  end
  return gameRealNameCall(a,...);
end

setreadonly(gameMt, true);